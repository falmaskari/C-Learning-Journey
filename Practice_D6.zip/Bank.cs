﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Day_s_Problem
{
    internal class BankAcount
    {
        private const int MAX_AMOUNT = 1000;
        private string accountNumber;
        private decimal balance;
        public decimal getBalance(decimal Balance)
        {
            return balance;
        }
        public string Account(double Amount)
        {
            this.amount = Amount;
        }
        public double Getdwithdraw(double Amount)
        {
            return amount;
        }
        public double withdraw(double amount)
        {
            if()
        }

    }
}
